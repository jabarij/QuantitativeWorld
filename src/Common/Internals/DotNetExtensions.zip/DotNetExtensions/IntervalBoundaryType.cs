namespace QuantitativeWorld.DotNetExtensions
{
    internal enum IntervalBoundaryType
	{
		Open,
		Closed
	}
}
